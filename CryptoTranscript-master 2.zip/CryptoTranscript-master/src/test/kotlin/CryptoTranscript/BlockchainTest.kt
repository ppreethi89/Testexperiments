package CryptoTranscript

import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test

internal class BlockchainTest {

    @Test
    fun `Get latest block, chain just initialized, returns genesis block`() {
        val chain = CryptoTranscript.cryptoTranscript
        val latestBlock = chain.latestTranscriptBlock

        assertEquals(0, latestBlock.index)
        assertEquals("Genesis block", latestBlock.transcriptData)
        assertEquals(0, latestBlock.proofOfWork)
    }

    @Test
    fun `Mine block, block added to the chain`() {
        val chain = CryptoTranscript.cryptoTranscript

        val minedBlock = chain.mineTranscriptBlock("data")

        assertEquals(minedBlock, chain.latestTranscriptBlock)
    }



    @Test
    fun `Mine block, assert created values`() {
        val chain = CryptoTranscript.cryptoTranscript
        val genesisBlock = chain.latestTranscriptBlock

        val minedBlock = chain.mineTranscriptBlock("data")

        val expectedProofOfWork = 19

        assertEquals(genesisBlock.hash, minedBlock.previousHash)
        assertEquals("data", minedBlock.transcriptData)
        assertEquals(genesisBlock.index + 1, minedBlock.index)
        assertEquals(expectedProofOfWork, minedBlock.proofOfWork)
        assertNotNull(minedBlock.hash)
        assertNotNull(minedBlock.timestamp)
    }

    @Test
    fun `Fork block, simulate fork in the chain`() {
        val chain = CryptoTranscript.cryptoTranscript

        val minedBlock = chain.mineTranscriptBlock("data")

        assertEquals(minedBlock, chain.latestTranscriptBlock)
    }
}
