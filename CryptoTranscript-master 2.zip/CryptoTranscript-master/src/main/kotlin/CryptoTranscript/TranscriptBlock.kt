package CryptoTranscript

import com.sun.org.apache.xpath.internal.operations.Bool
import org.apache.commons.codec.digest.DigestUtils
import java.io.File
import java.util.*

class TranscriptBlock(val index: Int,
            val previousHash: String,
            var transcriptData: Any,
            val proofOfWork: Int,
                      val fork:Boolean,
                      var flag: String) {

    var hash = computeHash()
    val timestamp: Long = Date().time

     fun computeHash(): String {
       // val input = (index.toString() + previousHash + timestamp + transcriptData).toByteArray()
         //val input = (index.toString() + previousHash + timestamp + File("/Users/preethiprabhakar/Documents/src/SoftwareDesign/Test_PDF.pdf")).toByteArray()
         val input = (index.toString() + previousHash  +timestamp+ File("/Users/preethiprabhakar/Documents/src/SoftwareDesign/Test_FDP.pdf").readLines()).toByteArray()

        return DigestUtils.sha256Hex(input)
    }
}
