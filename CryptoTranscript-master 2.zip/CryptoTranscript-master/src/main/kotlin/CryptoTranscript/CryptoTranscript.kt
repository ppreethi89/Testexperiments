package CryptoTranscript

import io.javalin.Javalin.*

val cryptoTranscript= TranscriptBlockchain

fun main(args: Array<String>) {
    val app = start(7000)
    app.get("/blocks") { ctx ->
        ctx.json(cryptoTranscript.chain )

    }


    app.post("/blocks/mine") { ctx ->
        val minedTranscriptBlock = cryptoTranscript.mineTranscriptBlock(ctx.body())
        ctx.json(minedTranscriptBlock)
    }

    app.put("/blocks") { ctx ->
        val inputParameters=ctx.body().split("\n")
        val minedBlock = cryptoTranscript.tamperExistingTranscriptBlock(inputParameters[0].toInt(), inputParameters[1])
        ctx.json(minedBlock)
    }

    app.post("/blocks/fork") { ctx ->

        cryptoTranscript.createfork1()
        cryptoTranscript.createfork2()
        ctx.json( cryptoTranscript.chain_fork_1 + cryptoTranscript.chain_fork_2 )
    }

    app.get("/blocks/longestchain") { ctx ->
        cryptoTranscript.findlongestchain()
        ctx.json( cryptoTranscript.chain )

    }

}
